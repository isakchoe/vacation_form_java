package kakaoStyle.vacation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VacationApplicationTests {

	@Test
	void contextLoads() {
	}

}
